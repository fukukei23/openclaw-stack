# Operations Docs

This directory stores sanitized operational documentation for OpenClaw.

## Contents

- `ARCHITECTURE.md`: architecture summary for operations.
- `PAIRING_RECOVERY.md`: pairing recovery procedure.
- `SANITIZE_RUNBOOK.md`: sanitization checklist before publishing artifacts.
- `sanitized-archive/`: redacted snapshots only. Never store raw secrets here.

## Publication Rule

Only files with secrets replaced by `<REDACTED>` may be committed or published.
